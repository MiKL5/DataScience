```python
import numpy             as np
import pandas            as pd
import matplotlib.pyplot as plt
import seaborn           as sns
import plotly.express    as px
```


```python
data_universities = pd.read_excel('data_universite.xlsx')
data_universities
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP code</th>
      <th>Highest degree offered</th>
      <th>County name</th>
      <th>Longitude location of institution</th>
      <th>Latitude location of institution</th>
      <th>Religious affiliation</th>
      <th>Offers Less than one year certificate</th>
      <th>...</th>
      <th>Percent of freshmen  receiving federal grant aid</th>
      <th>Percent of freshmen receiving Pell grants</th>
      <th>Percent of freshmen receiving other federal grant aid</th>
      <th>Percent of freshmen receiving state/local grant aid</th>
      <th>Percent of freshmen receiving institutional grant aid</th>
      <th>Percent of freshmen receiving student loan aid</th>
      <th>Percent of freshmen receiving federal student loans</th>
      <th>Percent of freshmen receiving other loan aid</th>
      <th>Endowment assets (year end) per FTE enrollment (GASB)</th>
      <th>Endowment assets (year end) per FTE enrollment (FASB)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100654</td>
      <td>Alabama A &amp; M University</td>
      <td>2013</td>
      <td>35762</td>
      <td>Doctor's degree - research/scholarship</td>
      <td>Madison County</td>
      <td>-86.568502</td>
      <td>34.783368</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>32.0</td>
      <td>89.0</td>
      <td>89.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100663</td>
      <td>University of Alabama at Birmingham</td>
      <td>2013</td>
      <td>35294-0110</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Jefferson County</td>
      <td>-86.809170</td>
      <td>33.502230</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>36.0</td>
      <td>36.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>56.0</td>
      <td>55.0</td>
      <td>5.0</td>
      <td>24136.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100690</td>
      <td>Amridge University</td>
      <td>2013</td>
      <td>36117-3553</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.174010</td>
      <td>32.362609</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>0.0</td>
      <td>40.0</td>
      <td>90.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>302.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100706</td>
      <td>University of Alabama in Huntsville</td>
      <td>2013</td>
      <td>35899</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Madison County</td>
      <td>-86.638420</td>
      <td>34.722818</td>
      <td>Not applicable</td>
      <td>Yes</td>
      <td>...</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>63.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>3.0</td>
      <td>11502.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100724</td>
      <td>Alabama State University</td>
      <td>2013</td>
      <td>36104-0271</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.295677</td>
      <td>32.364317</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>76.0</td>
      <td>76.0</td>
      <td>13.0</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>13202.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1529</th>
      <td>451671</td>
      <td>University of South Florida-Sarasota-Manatee</td>
      <td>2013</td>
      <td>34243-2049</td>
      <td>Master's degree</td>
      <td>Manatee County</td>
      <td>-82.562951</td>
      <td>27.391766</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4422.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1530</th>
      <td>454184</td>
      <td>The Kingâ€™s College</td>
      <td>2013</td>
      <td>10004</td>
      <td>Bachelor's degree</td>
      <td>New York County</td>
      <td>-74.012348</td>
      <td>40.706861</td>
      <td>Interdenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>34.0</td>
      <td>34.0</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>100.0</td>
      <td>57.0</td>
      <td>56.0</td>
      <td>12.0</td>
      <td>NaN</td>
      <td>935.0</td>
    </tr>
    <tr>
      <th>1531</th>
      <td>454582</td>
      <td>Ottawa University-Online</td>
      <td>2013</td>
      <td>66067</td>
      <td>Master's degree</td>
      <td>Franklin County</td>
      <td>-95.263775</td>
      <td>38.602692</td>
      <td>American Baptist</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20863.0</td>
    </tr>
    <tr>
      <th>1532</th>
      <td>455770</td>
      <td>Providence Christian College</td>
      <td>2013</td>
      <td>91104</td>
      <td>Bachelor's degree</td>
      <td>Los Angeles County</td>
      <td>-118.118491</td>
      <td>34.172750</td>
      <td>Undenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>14.0</td>
      <td>0.0</td>
      <td>100.0</td>
      <td>64.0</td>
      <td>64.0</td>
      <td>14.0</td>
      <td>NaN</td>
      <td>350.0</td>
    </tr>
    <tr>
      <th>1533</th>
      <td>456490</td>
      <td>Polytechnic University of Puerto Rico-Orlando</td>
      <td>2013</td>
      <td>32825</td>
      <td>Master's degree</td>
      <td>Orange County</td>
      <td>-81.254951</td>
      <td>28.551470</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1534 rows × 145 columns</p>
</div>




```python
data_universities.shape
```




    (1534, 145)




```python
data_universities.columns
```




    Index(['ID number', 'Name', 'year', 'ZIP code', 'Highest degree offered',
           'County name', 'Longitude location of institution',
           'Latitude location of institution', 'Religious affiliation',
           'Offers Less than one year certificate',
           ...
           'Percent of freshmen  receiving federal grant aid',
           'Percent of freshmen receiving Pell grants',
           'Percent of freshmen receiving other federal grant aid',
           'Percent of freshmen receiving state/local grant aid',
           'Percent of freshmen receiving institutional grant aid',
           'Percent of freshmen receiving student loan aid',
           'Percent of freshmen receiving federal student loans',
           'Percent of freshmen receiving other loan aid',
           'Endowment assets (year end) per FTE enrollment (GASB)',
           'Endowment assets (year end) per FTE enrollment (FASB)'],
          dtype='object', length=145)




```python
data_universities.columns.to_list()
```




    ['ID number',
     'Name',
     'year',
     'ZIP code',
     'Highest degree offered',
     'County name',
     'Longitude location of institution',
     'Latitude location of institution',
     'Religious affiliation',
     'Offers Less than one year certificate',
     'Offers One but less than two years certificate',
     "Offers Associate's degree",
     'Offers Two but less than 4 years certificate',
     "Offers Bachelor's degree",
     'Offers Postbaccalaureate certificate',
     "Offers Master's degree",
     "Offers Post-master's certificate",
     "Offers Doctor's degree - research/scholarship",
     "Offers Doctor's degree - professional practice",
     "Offers Doctor's degree - other",
     'Offers Other degree',
     'Applicants total',
     'Admissions total',
     'Enrolled total',
     'Percent of freshmen submitting SAT scores',
     'Percent of freshmen submitting ACT scores',
     'SAT Critical Reading 25th percentile score',
     'SAT Critical Reading 75th percentile score',
     'SAT Math 25th percentile score',
     'SAT Math 75th percentile score',
     'SAT Writing 25th percentile score',
     'SAT Writing 75th percentile score',
     'ACT Composite 25th percentile score',
     'ACT Composite 75th percentile score',
     'Estimated enrollment, total',
     'Estimated enrollment, full time',
     'Estimated enrollment, part time',
     'Estimated undergraduate enrollment, total',
     'Estimated undergraduate enrollment, full time',
     'Estimated undergraduate enrollment, part time',
     'Estimated freshman undergraduate enrollment, total',
     'Estimated freshman enrollment, full time',
     'Estimated freshman enrollment, part time',
     'Estimated graduate enrollment, total',
     'Estimated graduate enrollment, full time',
     'Estimated graduate enrollment, part time',
     "Associate's degrees awarded",
     "Bachelor's degrees awarded",
     "Master's degrees awarded",
     "Doctor's degrese - research/scholarship awarded",
     "Doctor's degrees - professional practice awarded",
     "Doctor's degrees - other awarded",
     'Certificates of less than 1-year awarded',
     'Certificates of 1 but less than 2-years awarded',
     'Certificates of 2 but less than 4-years awarded',
     'Postbaccalaureate certificates awarded',
     "Post-master's certificates awarded",
     "Number of students receiving an Associate's degree",
     "Number of students receiving a Bachelor's degree",
     "Number of students receiving a Master's degree",
     "Number of students receiving a Doctor's degree",
     'Number of students receiving a certificate of less than 1-year',
     'Number of students receiving a certificate of 1 but less than 4-years',
     "Number of students receiving a Postbaccalaureate or Post-master's certificate",
     'Percent admitted - total',
     'Admissions yield - total',
     'Tuition and fees, 2010-11',
     'Tuition and fees, 2011-12',
     'Tuition and fees, 2012-13',
     'Tuition and fees, 2013-14',
     'Total price for in-state students living on campus 2013-14',
     'Total price for out-of-state students living on campus 2013-14',
     'State abbreviation',
     'FIPS state code',
     'Geographic region',
     'Sector of institution',
     'Level of institution',
     'Control of institution',
     'Historically Black College or University',
     'Tribal college',
     'Degree of urbanization (Urban-centric locale)',
     'Carnegie Classification 2010: Basic',
     'Total  enrollment',
     'Full-time enrollment',
     'Part-time enrollment',
     'Undergraduate enrollment',
     'Graduate enrollment',
     'Full-time undergraduate enrollment',
     'Part-time undergraduate enrollment',
     'Percent of total enrollment that are American Indian or Alaska Native',
     'Percent of total enrollment that are Asian',
     'Percent of total enrollment that are Black or African American',
     'Percent of total enrollment that are Hispanic/Latino',
     'Percent of total enrollment that are Native Hawaiian or Other Pacific Islander',
     'Percent of total enrollment that are White',
     'Percent of total enrollment that are two or more races',
     'Percent of total enrollment that are Race/ethnicity unknown',
     'Percent of total enrollment that are Nonresident Alien',
     'Percent of total enrollment that are Asian/Native Hawaiian/Pacific Islander',
     'Percent of total enrollment that are women',
     'Percent of undergraduate enrollment that are American Indian or Alaska Native',
     'Percent of undergraduate enrollment that are Asian',
     'Percent of undergraduate enrollment that are Black or African American',
     'Percent of undergraduate enrollment that are Hispanic/Latino',
     'Percent of undergraduate enrollment that are Native Hawaiian or Other Pacific Islander',
     'Percent of undergraduate enrollment that are White',
     'Percent of undergraduate enrollment that are two or more races',
     'Percent of undergraduate enrollment that are Race/ethnicity unknown',
     'Percent of undergraduate enrollment that are Nonresident Alien',
     'Percent of undergraduate enrollment that are Asian/Native Hawaiian/Pacific Islander',
     'Percent of undergraduate enrollment that are women',
     'Percent of graduate enrollment that are American Indian or Alaska Native',
     'Percent of graduate enrollment that are Asian',
     'Percent of graduate enrollment that are Black or African American',
     'Percent of graduate enrollment that are Hispanic/Latino',
     'Percent of graduate enrollment that are Native Hawaiian or Other Pacific Islander',
     'Percent of graduate enrollment that are White',
     'Percent of graduate enrollment that are two or more races',
     'Percent of graduate enrollment that are Race/ethnicity unknown',
     'Percent of graduate enrollment that are Nonresident Alien',
     'Percent of graduate enrollment that are Asian/Native Hawaiian/Pacific Islander',
     'Percent of graduate enrollment that are women',
     'Number of first-time undergraduates - in-state',
     'Percent of first-time undergraduates - in-state',
     'Number of first-time undergraduates - out-of-state',
     'Percent of first-time undergraduates - out-of-state',
     'Number of first-time undergraduates - foreign countries',
     'Percent of first-time undergraduates - foreign countries',
     'Number of first-time undergraduates - residence unknown',
     'Percent of first-time undergraduates - residence unknown',
     'Graduation rate - Bachelor degree within 4 years, total',
     'Graduation rate - Bachelor degree within 5 years, total',
     'Graduation rate - Bachelor degree within 6 years, total',
     'Percent of freshmen receiving any financial aid',
     'Percent of freshmen receiving federal, state, local or institutional grant aid',
     'Percent of freshmen  receiving federal grant aid',
     'Percent of freshmen receiving Pell grants',
     'Percent of freshmen receiving other federal grant aid',
     'Percent of freshmen receiving state/local grant aid',
     'Percent of freshmen receiving institutional grant aid',
     'Percent of freshmen receiving student loan aid',
     'Percent of freshmen receiving federal student loans',
     'Percent of freshmen receiving other loan aid',
     'Endowment assets (year end) per FTE enrollment (GASB)',
     'Endowment assets (year end) per FTE enrollment (FASB)']




```python
# Avec un print classique, c'est dûr à lire ; utiliser value
print(data_universities.columns.values)
```

    ['ID number' 'Name' 'year' 'ZIP code' 'Highest degree offered'
     'County name' 'Longitude location of institution'
     'Latitude location of institution' 'Religious affiliation'
     'Offers Less than one year certificate'
     'Offers One but less than two years certificate'
     "Offers Associate's degree"
     'Offers Two but less than 4 years certificate' "Offers Bachelor's degree"
     'Offers Postbaccalaureate certificate' "Offers Master's degree"
     "Offers Post-master's certificate"
     "Offers Doctor's degree - research/scholarship"
     "Offers Doctor's degree - professional practice"
     "Offers Doctor's degree - other" 'Offers Other degree' 'Applicants total'
     'Admissions total' 'Enrolled total'
     'Percent of freshmen submitting SAT scores'
     'Percent of freshmen submitting ACT scores'
     'SAT Critical Reading 25th percentile score'
     'SAT Critical Reading 75th percentile score'
     'SAT Math 25th percentile score' 'SAT Math 75th percentile score'
     'SAT Writing 25th percentile score' 'SAT Writing 75th percentile score'
     'ACT Composite 25th percentile score'
     'ACT Composite 75th percentile score' 'Estimated enrollment, total'
     'Estimated enrollment, full time' 'Estimated enrollment, part time'
     'Estimated undergraduate enrollment, total'
     'Estimated undergraduate enrollment, full time'
     'Estimated undergraduate enrollment, part time'
     'Estimated freshman undergraduate enrollment, total'
     'Estimated freshman enrollment, full time'
     'Estimated freshman enrollment, part time'
     'Estimated graduate enrollment, total'
     'Estimated graduate enrollment, full time'
     'Estimated graduate enrollment, part time' "Associate's degrees awarded"
     "Bachelor's degrees awarded" "Master's degrees awarded"
     "Doctor's degrese - research/scholarship awarded"
     "Doctor's degrees - professional practice awarded"
     "Doctor's degrees - other awarded"
     'Certificates of less than 1-year awarded'
     'Certificates of 1 but less than 2-years awarded'
     'Certificates of 2 but less than 4-years awarded'
     'Postbaccalaureate certificates awarded'
     "Post-master's certificates awarded"
     "Number of students receiving an Associate's degree"
     "Number of students receiving a Bachelor's degree"
     "Number of students receiving a Master's degree"
     "Number of students receiving a Doctor's degree"
     'Number of students receiving a certificate of less than 1-year'
     'Number of students receiving a certificate of 1 but less than 4-years'
     "Number of students receiving a Postbaccalaureate or Post-master's certificate"
     'Percent admitted - total' 'Admissions yield - total'
     'Tuition and fees, 2010-11' 'Tuition and fees, 2011-12'
     'Tuition and fees, 2012-13' 'Tuition and fees, 2013-14'
     'Total price for in-state students living on campus 2013-14'
     'Total price for out-of-state students living on campus 2013-14'
     'State abbreviation' 'FIPS state code' 'Geographic region'
     'Sector of institution' 'Level of institution' 'Control of institution'
     'Historically Black College or University' 'Tribal college'
     'Degree of urbanization (Urban-centric locale)'
     'Carnegie Classification 2010: Basic' 'Total  enrollment'
     'Full-time enrollment' 'Part-time enrollment' 'Undergraduate enrollment'
     'Graduate enrollment' 'Full-time undergraduate enrollment'
     'Part-time undergraduate enrollment'
     'Percent of total enrollment that are American Indian or Alaska Native'
     'Percent of total enrollment that are Asian'
     'Percent of total enrollment that are Black or African American'
     'Percent of total enrollment that are Hispanic/Latino'
     'Percent of total enrollment that are Native Hawaiian or Other Pacific Islander'
     'Percent of total enrollment that are White'
     'Percent of total enrollment that are two or more races'
     'Percent of total enrollment that are Race/ethnicity unknown'
     'Percent of total enrollment that are Nonresident Alien'
     'Percent of total enrollment that are Asian/Native Hawaiian/Pacific Islander'
     'Percent of total enrollment that are women'
     'Percent of undergraduate enrollment that are American Indian or Alaska Native'
     'Percent of undergraduate enrollment that are Asian'
     'Percent of undergraduate enrollment that are Black or African American'
     'Percent of undergraduate enrollment that are Hispanic/Latino'
     'Percent of undergraduate enrollment that are Native Hawaiian or Other Pacific Islander'
     'Percent of undergraduate enrollment that are White'
     'Percent of undergraduate enrollment that are two or more races'
     'Percent of undergraduate enrollment that are Race/ethnicity unknown'
     'Percent of undergraduate enrollment that are Nonresident Alien'
     'Percent of undergraduate enrollment that are Asian/Native Hawaiian/Pacific Islander'
     'Percent of undergraduate enrollment that are women'
     'Percent of graduate enrollment that are American Indian or Alaska Native'
     'Percent of graduate enrollment that are Asian'
     'Percent of graduate enrollment that are Black or African American'
     'Percent of graduate enrollment that are Hispanic/Latino'
     'Percent of graduate enrollment that are Native Hawaiian or Other Pacific Islander'
     'Percent of graduate enrollment that are White'
     'Percent of graduate enrollment that are two or more races'
     'Percent of graduate enrollment that are Race/ethnicity unknown'
     'Percent of graduate enrollment that are Nonresident Alien'
     'Percent of graduate enrollment that are Asian/Native Hawaiian/Pacific Islander'
     'Percent of graduate enrollment that are women'
     'Number of first-time undergraduates - in-state'
     'Percent of first-time undergraduates - in-state'
     'Number of first-time undergraduates - out-of-state'
     'Percent of first-time undergraduates - out-of-state'
     'Number of first-time undergraduates - foreign countries'
     'Percent of first-time undergraduates - foreign countries'
     'Number of first-time undergraduates - residence unknown'
     'Percent of first-time undergraduates - residence unknown'
     'Graduation rate - Bachelor degree within 4 years, total'
     'Graduation rate - Bachelor degree within 5 years, total'
     'Graduation rate - Bachelor degree within 6 years, total'
     'Percent of freshmen receiving any financial aid'
     'Percent of freshmen receiving federal, state, local or institutional grant aid'
     'Percent of freshmen  receiving federal grant aid'
     'Percent of freshmen receiving Pell grants'
     'Percent of freshmen receiving other federal grant aid'
     'Percent of freshmen receiving state/local grant aid'
     'Percent of freshmen receiving institutional grant aid'
     'Percent of freshmen receiving student loan aid'
     'Percent of freshmen receiving federal student loans'
     'Percent of freshmen receiving other loan aid'
     'Endowment assets (year end) per FTE enrollment (GASB)'
     'Endowment assets (year end) per FTE enrollment (FASB)']



```python
# Le titre des colonnes, leur type (toutes les colonnes)
data_universities.info(max_cols = len(data_universities))
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1534 entries, 0 to 1533
    Data columns (total 145 columns):
     #    Column                                                                                  Non-Null Count  Dtype  
    ---   ------                                                                                  --------------  -----  
     0    ID number                                                                               1534 non-null   int64  
     1    Name                                                                                    1534 non-null   object 
     2    year                                                                                    1534 non-null   int64  
     3    ZIP code                                                                                1534 non-null   object 
     4    Highest degree offered                                                                  1534 non-null   object 
     5    County name                                                                             1534 non-null   object 
     6    Longitude location of institution                                                       1534 non-null   float64
     7    Latitude location of institution                                                        1534 non-null   float64
     8    Religious affiliation                                                                   1532 non-null   object 
     9    Offers Less than one year certificate                                                   1532 non-null   object 
     10   Offers One but less than two years certificate                                          1532 non-null   object 
     11   Offers Associate's degree                                                               1532 non-null   object 
     12   Offers Two but less than 4 years certificate                                            1532 non-null   object 
     13   Offers Bachelor's degree                                                                1532 non-null   object 
     14   Offers Postbaccalaureate certificate                                                    1532 non-null   object 
     15   Offers Master's degree                                                                  1532 non-null   object 
     16   Offers Post-master's certificate                                                        1532 non-null   object 
     17   Offers Doctor's degree - research/scholarship                                           1532 non-null   object 
     18   Offers Doctor's degree - professional practice                                          1532 non-null   object 
     19   Offers Doctor's degree - other                                                          1532 non-null   object 
     20   Offers Other degree                                                                     1532 non-null   object 
     21   Applicants total                                                                        1377 non-null   float64
     22   Admissions total                                                                        1377 non-null   float64
     23   Enrolled total                                                                          1377 non-null   float64
     24   Percent of freshmen submitting SAT scores                                               1257 non-null   float64
     25   Percent of freshmen submitting ACT scores                                               1259 non-null   float64
     26   SAT Critical Reading 25th percentile score                                              1169 non-null   float64
     27   SAT Critical Reading 75th percentile score                                              1169 non-null   float64
     28   SAT Math 25th percentile score                                                          1182 non-null   float64
     29   SAT Math 75th percentile score                                                          1182 non-null   float64
     30   SAT Writing 25th percentile score                                                       714 non-null    float64
     31   SAT Writing 75th percentile score                                                       714 non-null    float64
     32   ACT Composite 25th percentile score                                                     1199 non-null   float64
     33   ACT Composite 75th percentile score                                                     1199 non-null   float64
     34   Estimated enrollment, total                                                             1532 non-null   float64
     35   Estimated enrollment, full time                                                         1531 non-null   float64
     36   Estimated enrollment, part time                                                         1523 non-null   float64
     37   Estimated undergraduate enrollment, total                                               1526 non-null   float64
     38   Estimated undergraduate enrollment, full time                                           1525 non-null   float64
     39   Estimated undergraduate enrollment, part time                                           1514 non-null   float64
     40   Estimated freshman undergraduate enrollment, total                                      1515 non-null   float64
     41   Estimated freshman enrollment, full time                                                1515 non-null   float64
     42   Estimated freshman enrollment, part time                                                1451 non-null   float64
     43   Estimated graduate enrollment, total                                                    1432 non-null   float64
     44   Estimated graduate enrollment, full time                                                1422 non-null   float64
     45   Estimated graduate enrollment, part time                                                1420 non-null   float64
     46   Associate's degrees awarded                                                             1532 non-null   float64
     47   Bachelor's degrees awarded                                                              1532 non-null   float64
     48   Master's degrees awarded                                                                1532 non-null   float64
     49   Doctor's degrese - research/scholarship awarded                                         1532 non-null   float64
     50   Doctor's degrees - professional practice awarded                                        1532 non-null   float64
     51   Doctor's degrees - other awarded                                                        1532 non-null   float64
     52   Certificates of less than 1-year awarded                                                1532 non-null   float64
     53   Certificates of 1 but less than 2-years awarded                                         1532 non-null   float64
     54   Certificates of 2 but less than 4-years awarded                                         1532 non-null   float64
     55   Postbaccalaureate certificates awarded                                                  1532 non-null   float64
     56   Post-master's certificates awarded                                                      1532 non-null   float64
     57   Number of students receiving an Associate's degree                                      1532 non-null   float64
     58   Number of students receiving a Bachelor's degree                                        1532 non-null   float64
     59   Number of students receiving a Master's degree                                          1532 non-null   float64
     60   Number of students receiving a Doctor's degree                                          1532 non-null   float64
     61   Number of students receiving a certificate of less than 1-year                          1532 non-null   float64
     62   Number of students receiving a certificate of 1 but less than 4-years                   1532 non-null   float64
     63   Number of students receiving a Postbaccalaureate or Post-master's certificate           1532 non-null   float64
     64   Percent admitted - total                                                                1376 non-null   float64
     65   Admissions yield - total                                                                1376 non-null   float64
     66   Tuition and fees, 2010-11                                                               1490 non-null   float64
     67   Tuition and fees, 2011-12                                                               1490 non-null   float64
     68   Tuition and fees, 2012-13                                                               1492 non-null   float64
     69   Tuition and fees, 2013-14                                                               1497 non-null   float64
     70   Total price for in-state students living on campus 2013-14                              1400 non-null   float64
     71   Total price for out-of-state students living on campus 2013-14                          1400 non-null   float64
     72   State abbreviation                                                                      1534 non-null   object 
     73   FIPS state code                                                                         1534 non-null   object 
     74   Geographic region                                                                       1534 non-null   object 
     75   Sector of institution                                                                   1534 non-null   object 
     76   Level of institution                                                                    1534 non-null   object 
     77   Control of institution                                                                  1534 non-null   object 
     78   Historically Black College or University                                                1534 non-null   object 
     79   Tribal college                                                                          1534 non-null   object 
     80   Degree of urbanization (Urban-centric locale)                                           1534 non-null   object 
     81   Carnegie Classification 2010: Basic                                                     1534 non-null   object 
     82   Total  enrollment                                                                       1532 non-null   float64
     83   Full-time enrollment                                                                    1532 non-null   float64
     84   Part-time enrollment                                                                    1532 non-null   float64
     85   Undergraduate enrollment                                                                1532 non-null   float64
     86   Graduate enrollment                                                                     1532 non-null   float64
     87   Full-time undergraduate enrollment                                                      1532 non-null   float64
     88   Part-time undergraduate enrollment                                                      1532 non-null   float64
     89   Percent of total enrollment that are American Indian or Alaska Native                   1532 non-null   float64
     90   Percent of total enrollment that are Asian                                              1532 non-null   float64
     91   Percent of total enrollment that are Black or African American                          1532 non-null   float64
     92   Percent of total enrollment that are Hispanic/Latino                                    1532 non-null   float64
     93   Percent of total enrollment that are Native Hawaiian or Other Pacific Islander          1532 non-null   float64
     94   Percent of total enrollment that are White                                              1532 non-null   float64
     95   Percent of total enrollment that are two or more races                                  1532 non-null   float64
     96   Percent of total enrollment that are Race/ethnicity unknown                             1532 non-null   float64
     97   Percent of total enrollment that are Nonresident Alien                                  1532 non-null   float64
     98   Percent of total enrollment that are Asian/Native Hawaiian/Pacific Islander             1532 non-null   float64
     99   Percent of total enrollment that are women                                              1532 non-null   float64
     100  Percent of undergraduate enrollment that are American Indian or Alaska Native           1522 non-null   float64
     101  Percent of undergraduate enrollment that are Asian                                      1522 non-null   float64
     102  Percent of undergraduate enrollment that are Black or African American                  1522 non-null   float64
     103  Percent of undergraduate enrollment that are Hispanic/Latino                            1522 non-null   float64
     104  Percent of undergraduate enrollment that are Native Hawaiian or Other Pacific Islander  1522 non-null   float64
     105  Percent of undergraduate enrollment that are White                                      1522 non-null   float64
     106  Percent of undergraduate enrollment that are two or more races                          1522 non-null   float64
     107  Percent of undergraduate enrollment that are Race/ethnicity unknown                     1522 non-null   float64
     108  Percent of undergraduate enrollment that are Nonresident Alien                          1522 non-null   float64
     109  Percent of undergraduate enrollment that are Asian/Native Hawaiian/Pacific Islander     1522 non-null   float64
     110  Percent of undergraduate enrollment that are women                                      1522 non-null   float64
     111  Percent of graduate enrollment that are American Indian or Alaska Native                1269 non-null   float64
     112  Percent of graduate enrollment that are Asian                                           1269 non-null   float64
     113  Percent of graduate enrollment that are Black or African American                       1269 non-null   float64
     114  Percent of graduate enrollment that are Hispanic/Latino                                 1269 non-null   float64
     115  Percent of graduate enrollment that are Native Hawaiian or Other Pacific Islander       1269 non-null   float64
     116  Percent of graduate enrollment that are White                                           1269 non-null   float64
     117  Percent of graduate enrollment that are two or more races                               1269 non-null   float64
     118  Percent of graduate enrollment that are Race/ethnicity unknown                          1269 non-null   float64
     119  Percent of graduate enrollment that are Nonresident Alien                               1269 non-null   float64
     120  Percent of graduate enrollment that are Asian/Native Hawaiian/Pacific Islander          1269 non-null   float64
     121  Percent of graduate enrollment that are women                                           1269 non-null   float64
     122  Number of first-time undergraduates - in-state                                          911 non-null    float64
     123  Percent of first-time undergraduates - in-state                                         911 non-null    float64
     124  Number of first-time undergraduates - out-of-state                                      911 non-null    float64
     125  Percent of first-time undergraduates - out-of-state                                     911 non-null    float64
     126  Number of first-time undergraduates - foreign countries                                 911 non-null    float64
     127  Percent of first-time undergraduates - foreign countries                                911 non-null    float64
     128  Number of first-time undergraduates - residence unknown                                 911 non-null    float64
     129  Percent of first-time undergraduates - residence unknown                                911 non-null    float64
     130  Graduation rate - Bachelor degree within 4 years, total                                 1476 non-null   float64
     131  Graduation rate - Bachelor degree within 5 years, total                                 1476 non-null   float64
     132  Graduation rate - Bachelor degree within 6 years, total                                 1476 non-null   float64
     133  Percent of freshmen receiving any financial aid                                         1492 non-null   float64
     134  Percent of freshmen receiving federal, state, local or institutional grant aid          1492 non-null   float64
     135  Percent of freshmen  receiving federal grant aid                                        1492 non-null   float64
     136  Percent of freshmen receiving Pell grants                                               1492 non-null   float64
     137  Percent of freshmen receiving other federal grant aid                                   1492 non-null   float64
     138  Percent of freshmen receiving state/local grant aid                                     1492 non-null   float64
     139  Percent of freshmen receiving institutional grant aid                                   1492 non-null   float64
     140  Percent of freshmen receiving student loan aid                                          1492 non-null   float64
     141  Percent of freshmen receiving federal student loans                                     1492 non-null   float64
     142  Percent of freshmen receiving other loan aid                                            1492 non-null   float64
     143  Endowment assets (year end) per FTE enrollment (GASB)                                   516 non-null    float64
     144  Endowment assets (year end) per FTE enrollment (FASB)                                   960 non-null    float64
    dtypes: float64(116), int64(2), object(27)
    memory usage: 1.7+ MB


Certaines colonnes manquent de valeurs.

S'il manque plus de 20 % des valeurs, la représentation des données est trop biaisée.

👉 Utiliser `len` et multiplier par 100.


```python
# Quelles sont les colonnes dont il manque plus de 20 %.
colonnes_nan = data_universities.isnull().sum()/len(data_universities)*100
colonnes_nan
```




    ID number                                                 0.000000
    Name                                                      0.000000
    year                                                      0.000000
    ZIP code                                                  0.000000
    Highest degree offered                                    0.000000
                                                               ...    
    Percent of freshmen receiving student loan aid            2.737940
    Percent of freshmen receiving federal student loans       2.737940
    Percent of freshmen receiving other loan aid              2.737940
    Endowment assets (year end) per FTE enrollment (GASB)    66.362451
    Endowment assets (year end) per FTE enrollment (FASB)    37.418514
    Length: 145, dtype: float64



👉 Une représentation graphique des valeurs manquantes est nécessaire.


```python
plt.figure(figsize = (12,10))
nan_pourcent = colonnes_nan[colonnes_nan>=20].sort_values(ascending = False).plot.bar(title = "% de NAN")
```


    
![png](output_12_0.png)
    



```python
# Copier le dataset
data = data_universities.copy()
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP code</th>
      <th>Highest degree offered</th>
      <th>County name</th>
      <th>Longitude location of institution</th>
      <th>Latitude location of institution</th>
      <th>Religious affiliation</th>
      <th>Offers Less than one year certificate</th>
      <th>...</th>
      <th>Percent of freshmen  receiving federal grant aid</th>
      <th>Percent of freshmen receiving Pell grants</th>
      <th>Percent of freshmen receiving other federal grant aid</th>
      <th>Percent of freshmen receiving state/local grant aid</th>
      <th>Percent of freshmen receiving institutional grant aid</th>
      <th>Percent of freshmen receiving student loan aid</th>
      <th>Percent of freshmen receiving federal student loans</th>
      <th>Percent of freshmen receiving other loan aid</th>
      <th>Endowment assets (year end) per FTE enrollment (GASB)</th>
      <th>Endowment assets (year end) per FTE enrollment (FASB)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100654</td>
      <td>Alabama A &amp; M University</td>
      <td>2013</td>
      <td>35762</td>
      <td>Doctor's degree - research/scholarship</td>
      <td>Madison County</td>
      <td>-86.568502</td>
      <td>34.783368</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>32.0</td>
      <td>89.0</td>
      <td>89.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100663</td>
      <td>University of Alabama at Birmingham</td>
      <td>2013</td>
      <td>35294-0110</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Jefferson County</td>
      <td>-86.809170</td>
      <td>33.502230</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>36.0</td>
      <td>36.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>56.0</td>
      <td>55.0</td>
      <td>5.0</td>
      <td>24136.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100690</td>
      <td>Amridge University</td>
      <td>2013</td>
      <td>36117-3553</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.174010</td>
      <td>32.362609</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>0.0</td>
      <td>40.0</td>
      <td>90.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>302.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100706</td>
      <td>University of Alabama in Huntsville</td>
      <td>2013</td>
      <td>35899</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Madison County</td>
      <td>-86.638420</td>
      <td>34.722818</td>
      <td>Not applicable</td>
      <td>Yes</td>
      <td>...</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>63.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>3.0</td>
      <td>11502.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100724</td>
      <td>Alabama State University</td>
      <td>2013</td>
      <td>36104-0271</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.295677</td>
      <td>32.364317</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>76.0</td>
      <td>76.0</td>
      <td>13.0</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>13202.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 145 columns</p>
</div>




```python
# Convertir en liste
liste_colonnes_nan = colonnes_nan[colonnes_nan>=20].index.to_list()
liste_colonnes_nan
```




    ['SAT Critical Reading 25th percentile score',
     'SAT Critical Reading 75th percentile score',
     'SAT Math 25th percentile score',
     'SAT Math 75th percentile score',
     'SAT Writing 25th percentile score',
     'SAT Writing 75th percentile score',
     'ACT Composite 25th percentile score',
     'ACT Composite 75th percentile score',
     'Number of first-time undergraduates - in-state',
     'Percent of first-time undergraduates - in-state',
     'Number of first-time undergraduates - out-of-state',
     'Percent of first-time undergraduates - out-of-state',
     'Number of first-time undergraduates - foreign countries',
     'Percent of first-time undergraduates - foreign countries',
     'Number of first-time undergraduates - residence unknown',
     'Percent of first-time undergraduates - residence unknown',
     'Endowment assets (year end) per FTE enrollment (GASB)',
     'Endowment assets (year end) per FTE enrollment (FASB)']




```python
# Supprimer ces colonnes du dataset
data.drop(liste_colonnes_nan, axis = 1, inplace = True)
data.info(max_cols=len(data))
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1534 entries, 0 to 1533
    Data columns (total 127 columns):
     #    Column                                                                                  Non-Null Count  Dtype  
    ---   ------                                                                                  --------------  -----  
     0    ID number                                                                               1534 non-null   int64  
     1    Name                                                                                    1534 non-null   object 
     2    year                                                                                    1534 non-null   int64  
     3    ZIP code                                                                                1534 non-null   object 
     4    Highest degree offered                                                                  1534 non-null   object 
     5    County name                                                                             1534 non-null   object 
     6    Longitude location of institution                                                       1534 non-null   float64
     7    Latitude location of institution                                                        1534 non-null   float64
     8    Religious affiliation                                                                   1532 non-null   object 
     9    Offers Less than one year certificate                                                   1532 non-null   object 
     10   Offers One but less than two years certificate                                          1532 non-null   object 
     11   Offers Associate's degree                                                               1532 non-null   object 
     12   Offers Two but less than 4 years certificate                                            1532 non-null   object 
     13   Offers Bachelor's degree                                                                1532 non-null   object 
     14   Offers Postbaccalaureate certificate                                                    1532 non-null   object 
     15   Offers Master's degree                                                                  1532 non-null   object 
     16   Offers Post-master's certificate                                                        1532 non-null   object 
     17   Offers Doctor's degree - research/scholarship                                           1532 non-null   object 
     18   Offers Doctor's degree - professional practice                                          1532 non-null   object 
     19   Offers Doctor's degree - other                                                          1532 non-null   object 
     20   Offers Other degree                                                                     1532 non-null   object 
     21   Applicants total                                                                        1377 non-null   float64
     22   Admissions total                                                                        1377 non-null   float64
     23   Enrolled total                                                                          1377 non-null   float64
     24   Percent of freshmen submitting SAT scores                                               1257 non-null   float64
     25   Percent of freshmen submitting ACT scores                                               1259 non-null   float64
     26   Estimated enrollment, total                                                             1532 non-null   float64
     27   Estimated enrollment, full time                                                         1531 non-null   float64
     28   Estimated enrollment, part time                                                         1523 non-null   float64
     29   Estimated undergraduate enrollment, total                                               1526 non-null   float64
     30   Estimated undergraduate enrollment, full time                                           1525 non-null   float64
     31   Estimated undergraduate enrollment, part time                                           1514 non-null   float64
     32   Estimated freshman undergraduate enrollment, total                                      1515 non-null   float64
     33   Estimated freshman enrollment, full time                                                1515 non-null   float64
     34   Estimated freshman enrollment, part time                                                1451 non-null   float64
     35   Estimated graduate enrollment, total                                                    1432 non-null   float64
     36   Estimated graduate enrollment, full time                                                1422 non-null   float64
     37   Estimated graduate enrollment, part time                                                1420 non-null   float64
     38   Associate's degrees awarded                                                             1532 non-null   float64
     39   Bachelor's degrees awarded                                                              1532 non-null   float64
     40   Master's degrees awarded                                                                1532 non-null   float64
     41   Doctor's degrese - research/scholarship awarded                                         1532 non-null   float64
     42   Doctor's degrees - professional practice awarded                                        1532 non-null   float64
     43   Doctor's degrees - other awarded                                                        1532 non-null   float64
     44   Certificates of less than 1-year awarded                                                1532 non-null   float64
     45   Certificates of 1 but less than 2-years awarded                                         1532 non-null   float64
     46   Certificates of 2 but less than 4-years awarded                                         1532 non-null   float64
     47   Postbaccalaureate certificates awarded                                                  1532 non-null   float64
     48   Post-master's certificates awarded                                                      1532 non-null   float64
     49   Number of students receiving an Associate's degree                                      1532 non-null   float64
     50   Number of students receiving a Bachelor's degree                                        1532 non-null   float64
     51   Number of students receiving a Master's degree                                          1532 non-null   float64
     52   Number of students receiving a Doctor's degree                                          1532 non-null   float64
     53   Number of students receiving a certificate of less than 1-year                          1532 non-null   float64
     54   Number of students receiving a certificate of 1 but less than 4-years                   1532 non-null   float64
     55   Number of students receiving a Postbaccalaureate or Post-master's certificate           1532 non-null   float64
     56   Percent admitted - total                                                                1376 non-null   float64
     57   Admissions yield - total                                                                1376 non-null   float64
     58   Tuition and fees, 2010-11                                                               1490 non-null   float64
     59   Tuition and fees, 2011-12                                                               1490 non-null   float64
     60   Tuition and fees, 2012-13                                                               1492 non-null   float64
     61   Tuition and fees, 2013-14                                                               1497 non-null   float64
     62   Total price for in-state students living on campus 2013-14                              1400 non-null   float64
     63   Total price for out-of-state students living on campus 2013-14                          1400 non-null   float64
     64   State abbreviation                                                                      1534 non-null   object 
     65   FIPS state code                                                                         1534 non-null   object 
     66   Geographic region                                                                       1534 non-null   object 
     67   Sector of institution                                                                   1534 non-null   object 
     68   Level of institution                                                                    1534 non-null   object 
     69   Control of institution                                                                  1534 non-null   object 
     70   Historically Black College or University                                                1534 non-null   object 
     71   Tribal college                                                                          1534 non-null   object 
     72   Degree of urbanization (Urban-centric locale)                                           1534 non-null   object 
     73   Carnegie Classification 2010: Basic                                                     1534 non-null   object 
     74   Total  enrollment                                                                       1532 non-null   float64
     75   Full-time enrollment                                                                    1532 non-null   float64
     76   Part-time enrollment                                                                    1532 non-null   float64
     77   Undergraduate enrollment                                                                1532 non-null   float64
     78   Graduate enrollment                                                                     1532 non-null   float64
     79   Full-time undergraduate enrollment                                                      1532 non-null   float64
     80   Part-time undergraduate enrollment                                                      1532 non-null   float64
     81   Percent of total enrollment that are American Indian or Alaska Native                   1532 non-null   float64
     82   Percent of total enrollment that are Asian                                              1532 non-null   float64
     83   Percent of total enrollment that are Black or African American                          1532 non-null   float64
     84   Percent of total enrollment that are Hispanic/Latino                                    1532 non-null   float64
     85   Percent of total enrollment that are Native Hawaiian or Other Pacific Islander          1532 non-null   float64
     86   Percent of total enrollment that are White                                              1532 non-null   float64
     87   Percent of total enrollment that are two or more races                                  1532 non-null   float64
     88   Percent of total enrollment that are Race/ethnicity unknown                             1532 non-null   float64
     89   Percent of total enrollment that are Nonresident Alien                                  1532 non-null   float64
     90   Percent of total enrollment that are Asian/Native Hawaiian/Pacific Islander             1532 non-null   float64
     91   Percent of total enrollment that are women                                              1532 non-null   float64
     92   Percent of undergraduate enrollment that are American Indian or Alaska Native           1522 non-null   float64
     93   Percent of undergraduate enrollment that are Asian                                      1522 non-null   float64
     94   Percent of undergraduate enrollment that are Black or African American                  1522 non-null   float64
     95   Percent of undergraduate enrollment that are Hispanic/Latino                            1522 non-null   float64
     96   Percent of undergraduate enrollment that are Native Hawaiian or Other Pacific Islander  1522 non-null   float64
     97   Percent of undergraduate enrollment that are White                                      1522 non-null   float64
     98   Percent of undergraduate enrollment that are two or more races                          1522 non-null   float64
     99   Percent of undergraduate enrollment that are Race/ethnicity unknown                     1522 non-null   float64
     100  Percent of undergraduate enrollment that are Nonresident Alien                          1522 non-null   float64
     101  Percent of undergraduate enrollment that are Asian/Native Hawaiian/Pacific Islander     1522 non-null   float64
     102  Percent of undergraduate enrollment that are women                                      1522 non-null   float64
     103  Percent of graduate enrollment that are American Indian or Alaska Native                1269 non-null   float64
     104  Percent of graduate enrollment that are Asian                                           1269 non-null   float64
     105  Percent of graduate enrollment that are Black or African American                       1269 non-null   float64
     106  Percent of graduate enrollment that are Hispanic/Latino                                 1269 non-null   float64
     107  Percent of graduate enrollment that are Native Hawaiian or Other Pacific Islander       1269 non-null   float64
     108  Percent of graduate enrollment that are White                                           1269 non-null   float64
     109  Percent of graduate enrollment that are two or more races                               1269 non-null   float64
     110  Percent of graduate enrollment that are Race/ethnicity unknown                          1269 non-null   float64
     111  Percent of graduate enrollment that are Nonresident Alien                               1269 non-null   float64
     112  Percent of graduate enrollment that are Asian/Native Hawaiian/Pacific Islander          1269 non-null   float64
     113  Percent of graduate enrollment that are women                                           1269 non-null   float64
     114  Graduation rate - Bachelor degree within 4 years, total                                 1476 non-null   float64
     115  Graduation rate - Bachelor degree within 5 years, total                                 1476 non-null   float64
     116  Graduation rate - Bachelor degree within 6 years, total                                 1476 non-null   float64
     117  Percent of freshmen receiving any financial aid                                         1492 non-null   float64
     118  Percent of freshmen receiving federal, state, local or institutional grant aid          1492 non-null   float64
     119  Percent of freshmen  receiving federal grant aid                                        1492 non-null   float64
     120  Percent of freshmen receiving Pell grants                                               1492 non-null   float64
     121  Percent of freshmen receiving other federal grant aid                                   1492 non-null   float64
     122  Percent of freshmen receiving state/local grant aid                                     1492 non-null   float64
     123  Percent of freshmen receiving institutional grant aid                                   1492 non-null   float64
     124  Percent of freshmen receiving student loan aid                                          1492 non-null   float64
     125  Percent of freshmen receiving federal student loans                                     1492 non-null   float64
     126  Percent of freshmen receiving other loan aid                                            1492 non-null   float64
    dtypes: float64(98), int64(2), object(27)
    memory usage: 1.5+ MB


Il reste 127 colonnes.

La question est : "Quels sont les critères poussant un étudiant à préférer une université ?"

Donc, 8 colonnes m'intéressent.  
Elles seront stockées dans une liste ('university preference criteria') :
* Name ;
* Applicants total (candidats) ;
* Adminissions total ;
* Enrolled total (inscrits) ;
* Total price for in-state students living on campus 2013-14 ;
* Total price for out-of-state students living on campus 2013-14 (étudiants étrangés) ;
* Control of institution (école privée ou publique) ;
* Total enrollment.


```python
university_preference_criteria = ['Name', 'Applicants total', 'Admissions total', 'Enrolled total',
                                  'Total price for in-state students living on campus 2013-14',
                                 'Total price for out-of-state students living on campus 2013-14',
                                 'Control of institution', 'Total  enrollment']

preference = data[university_preference_criteria]
preference.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Applicants total</th>
      <th>Admissions total</th>
      <th>Enrolled total</th>
      <th>Total price for in-state students living on campus 2013-14</th>
      <th>Total price for out-of-state students living on campus 2013-14</th>
      <th>Control of institution</th>
      <th>Total  enrollment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alabama A &amp; M University</td>
      <td>6142.0</td>
      <td>5521.0</td>
      <td>1104.0</td>
      <td>21849.0</td>
      <td>27441.0</td>
      <td>Public</td>
      <td>5020.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>University of Alabama at Birmingham</td>
      <td>5689.0</td>
      <td>4934.0</td>
      <td>1773.0</td>
      <td>22495.0</td>
      <td>31687.0</td>
      <td>Public</td>
      <td>18568.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Amridge University</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Private not-for-profit</td>
      <td>631.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>University of Alabama in Huntsville</td>
      <td>2054.0</td>
      <td>1656.0</td>
      <td>651.0</td>
      <td>23466.0</td>
      <td>35780.0</td>
      <td>Public</td>
      <td>7376.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alabama State University</td>
      <td>10245.0</td>
      <td>5251.0</td>
      <td>1479.0</td>
      <td>18286.0</td>
      <td>25222.0</td>
      <td>Public</td>
      <td>6075.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Y a-t-il des valeurs manquantes ?
na_values = preference.isnull().sum()
na_values
```




    Name                                                                0
    Applicants total                                                  157
    Admissions total                                                  157
    Enrolled total                                                    157
    Total price for in-state students living on campus 2013-14        134
    Total price for out-of-state students living on campus 2013-14    134
    Control of institution                                              0
    Total  enrollment                                                   2
    dtype: int64



Ici, il n'y a pas d'autre possibilité que de supprimer les lignes.  
Le dataset, ne contient pas les données des années précédentes.  
Par conséquent, il est impossible de calculer une moyenne.


```python
# Suppression
preference = preference.dropna(subset=['Applicants total', 'Admissions total', 'Enrolled total',
                                       'Total price for in-state students living on campus 2013-14',
                                       'Total price for out-of-state students living on campus 2013-14',
                                       'Total  enrollment'])

na_values = preference.isnull().sum()
na_values
```




    Name                                                              0
    Applicants total                                                  0
    Admissions total                                                  0
    Enrolled total                                                    0
    Total price for in-state students living on campus 2013-14        0
    Total price for out-of-state students living on campus 2013-14    0
    Control of institution                                            0
    Total  enrollment                                                 0
    dtype: int64




```python
# Combien de lignes reste t-il ?
preference.shape
```




    (1326, 8)




```python
# Avoir un point de vue global de la populationabs
preference.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Applicants total</th>
      <th>Admissions total</th>
      <th>Enrolled total</th>
      <th>Total price for in-state students living on campus 2013-14</th>
      <th>Total price for out-of-state students living on campus 2013-14</th>
      <th>Total  enrollment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1326.000000</td>
      <td>1326.000000</td>
      <td>1326.000000</td>
      <td>1326.000000</td>
      <td>1326.000000</td>
      <td>1326.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>6562.079186</td>
      <td>3638.870287</td>
      <td>1064.596531</td>
      <td>35607.657617</td>
      <td>39457.417798</td>
      <td>7501.159879</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8887.252631</td>
      <td>4346.785651</td>
      <td>1297.577558</td>
      <td>13211.675469</td>
      <td>10464.105131</td>
      <td>9664.482557</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.000000</td>
      <td>4.000000</td>
      <td>2.000000</td>
      <td>11398.000000</td>
      <td>11398.000000</td>
      <td>66.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1595.500000</td>
      <td>995.250000</td>
      <td>298.000000</td>
      <td>23172.250000</td>
      <td>31842.000000</td>
      <td>1701.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3452.000000</td>
      <td>2092.500000</td>
      <td>545.000000</td>
      <td>35185.000000</td>
      <td>37902.000000</td>
      <td>3414.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7135.250000</td>
      <td>4347.750000</td>
      <td>1265.750000</td>
      <td>45469.500000</td>
      <td>46323.000000</td>
      <td>8943.750000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>72676.000000</td>
      <td>35815.000000</td>
      <td>10241.000000</td>
      <td>64988.000000</td>
      <td>64988.000000</td>
      <td>77338.000000</td>
    </tr>
  </tbody>
</table>
</div>



1326 universités  
6562 candidatures moyennes par université
8887 certaines universités ont un très grand nombre de candidatures  
D'autres très peu  
Le dernier quartile, montre qu'une université à 72676 candidatures pour 2013-14


```python
# Quelle école n'a que 4 candidature ?
preference[['Name', 'Applicants total']].sort_values('Applicants total').head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Applicants total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1343</th>
      <td>Goddard College</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1354</th>
      <td>Sterling College</td>
      <td>49.0</td>
    </tr>
    <tr>
      <th>396</th>
      <td>Maharishi University of Management</td>
      <td>74.0</td>
    </tr>
    <tr>
      <th>155</th>
      <td>Naropa University</td>
      <td>79.0</td>
    </tr>
    <tr>
      <th>105</th>
      <td>American Jewish University</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>1222</th>
      <td>Aquinas College</td>
      <td>119.0</td>
    </tr>
    <tr>
      <th>1532</th>
      <td>Providence Christian College</td>
      <td>122.0</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Alliant International University</td>
      <td>128.0</td>
    </tr>
    <tr>
      <th>1489</th>
      <td>Beacon College</td>
      <td>139.0</td>
    </tr>
    <tr>
      <th>614</th>
      <td>Kuyper College</td>
      <td>152.0</td>
    </tr>
  </tbody>
</table>
</div>



Celon "datausa.io", c'est habituel.

_Les virgules, tirets, barres de fraction, etc, peuvent être problématiques._  
_Il faut les replacer par "`_`"._
_Ou l'appeler entre crochets et guillemmets._


```python
liste = []
mot   = "Total price for in-state students living on campus 2013-14".split()
size  = int(len(mot))
for i in range(size):
    if i < size -1:
        liste.append(mot[i] + '_')
    else:
        liste.append(mot[i])

liste
```




    ['Total_',
     'price_',
     'for_',
     'in-state_',
     'students_',
     'living_',
     'on_',
     'campus_',
     '2013-14']




```python
intitule = ''.join(liste)
intitule
```




    'Total_price_for_in-state_students_living_on_campus_2013-14'



C'est une perte de temps, une fonction est plus rapide et plus efficace.


```python
def remove_space(column_name):
    word_list = []
    words = column_name.split()
    size = len(words)
    for i in range(size):
        if i < size - 1:
            word_list.append(words[i] + '_')
        else:
            word_list.append(words[i])

    new_column_name = ''.join(word_list)
    return new_column_name
```


```python
remove_space("Total price for out-of-state students living on campus 2013-14")
```




    'Total_price_for_out-of-state_students_living_on_campus_2013-14'




```python
new_title   = []
cols        = data.columns
for col in cols:
    new_col = remove_space(col)
    new_title.append(new_col)

new_title
```




    ['ID_number',
     'Name',
     'year',
     'ZIP_code',
     'Highest_degree_offered',
     'County_name',
     'Longitude_location_of_institution',
     'Latitude_location_of_institution',
     'Religious_affiliation',
     'Offers_Less_than_one_year_certificate',
     'Offers_One_but_less_than_two_years_certificate',
     "Offers_Associate's_degree",
     'Offers_Two_but_less_than_4_years_certificate',
     "Offers_Bachelor's_degree",
     'Offers_Postbaccalaureate_certificate',
     "Offers_Master's_degree",
     "Offers_Post-master's_certificate",
     "Offers_Doctor's_degree_-_research/scholarship",
     "Offers_Doctor's_degree_-_professional_practice",
     "Offers_Doctor's_degree_-_other",
     'Offers_Other_degree',
     'Applicants_total',
     'Admissions_total',
     'Enrolled_total',
     'Percent_of_freshmen_submitting_SAT_scores',
     'Percent_of_freshmen_submitting_ACT_scores',
     'Estimated_enrollment,_total',
     'Estimated_enrollment,_full_time',
     'Estimated_enrollment,_part_time',
     'Estimated_undergraduate_enrollment,_total',
     'Estimated_undergraduate_enrollment,_full_time',
     'Estimated_undergraduate_enrollment,_part_time',
     'Estimated_freshman_undergraduate_enrollment,_total',
     'Estimated_freshman_enrollment,_full_time',
     'Estimated_freshman_enrollment,_part_time',
     'Estimated_graduate_enrollment,_total',
     'Estimated_graduate_enrollment,_full_time',
     'Estimated_graduate_enrollment,_part_time',
     "Associate's_degrees_awarded",
     "Bachelor's_degrees_awarded",
     "Master's_degrees_awarded",
     "Doctor's_degrese_-_research/scholarship_awarded",
     "Doctor's_degrees_-_professional_practice_awarded",
     "Doctor's_degrees_-_other_awarded",
     'Certificates_of_less_than_1-year_awarded',
     'Certificates_of_1_but_less_than_2-years_awarded',
     'Certificates_of_2_but_less_than_4-years_awarded',
     'Postbaccalaureate_certificates_awarded',
     "Post-master's_certificates_awarded",
     "Number_of_students_receiving_an_Associate's_degree",
     "Number_of_students_receiving_a_Bachelor's_degree",
     "Number_of_students_receiving_a_Master's_degree",
     "Number_of_students_receiving_a_Doctor's_degree",
     'Number_of_students_receiving_a_certificate_of_less_than_1-year',
     'Number_of_students_receiving_a_certificate_of_1_but_less_than_4-years',
     "Number_of_students_receiving_a_Postbaccalaureate_or_Post-master's_certificate",
     'Percent_admitted_-_total',
     'Admissions_yield_-_total',
     'Tuition_and_fees,_2010-11',
     'Tuition_and_fees,_2011-12',
     'Tuition_and_fees,_2012-13',
     'Tuition_and_fees,_2013-14',
     'Total_price_for_in-state_students_living_on_campus_2013-14',
     'Total_price_for_out-of-state_students_living_on_campus_2013-14',
     'State_abbreviation',
     'FIPS_state_code',
     'Geographic_region',
     'Sector_of_institution',
     'Level_of_institution',
     'Control_of_institution',
     'Historically_Black_College_or_University',
     'Tribal_college',
     'Degree_of_urbanization_(Urban-centric_locale)',
     'Carnegie_Classification_2010:_Basic',
     'Total_enrollment',
     'Full-time_enrollment',
     'Part-time_enrollment',
     'Undergraduate_enrollment',
     'Graduate_enrollment',
     'Full-time_undergraduate_enrollment',
     'Part-time_undergraduate_enrollment',
     'Percent_of_total_enrollment_that_are_American_Indian_or_Alaska_Native',
     'Percent_of_total_enrollment_that_are_Asian',
     'Percent_of_total_enrollment_that_are_Black_or_African_American',
     'Percent_of_total_enrollment_that_are_Hispanic/Latino',
     'Percent_of_total_enrollment_that_are_Native_Hawaiian_or_Other_Pacific_Islander',
     'Percent_of_total_enrollment_that_are_White',
     'Percent_of_total_enrollment_that_are_two_or_more_races',
     'Percent_of_total_enrollment_that_are_Race/ethnicity_unknown',
     'Percent_of_total_enrollment_that_are_Nonresident_Alien',
     'Percent_of_total_enrollment_that_are_Asian/Native_Hawaiian/Pacific_Islander',
     'Percent_of_total_enrollment_that_are_women',
     'Percent_of_undergraduate_enrollment_that_are_American_Indian_or_Alaska_Native',
     'Percent_of_undergraduate_enrollment_that_are_Asian',
     'Percent_of_undergraduate_enrollment_that_are_Black_or_African_American',
     'Percent_of_undergraduate_enrollment_that_are_Hispanic/Latino',
     'Percent_of_undergraduate_enrollment_that_are_Native_Hawaiian_or_Other_Pacific_Islander',
     'Percent_of_undergraduate_enrollment_that_are_White',
     'Percent_of_undergraduate_enrollment_that_are_two_or_more_races',
     'Percent_of_undergraduate_enrollment_that_are_Race/ethnicity_unknown',
     'Percent_of_undergraduate_enrollment_that_are_Nonresident_Alien',
     'Percent_of_undergraduate_enrollment_that_are_Asian/Native_Hawaiian/Pacific_Islander',
     'Percent_of_undergraduate_enrollment_that_are_women',
     'Percent_of_graduate_enrollment_that_are_American_Indian_or_Alaska_Native',
     'Percent_of_graduate_enrollment_that_are_Asian',
     'Percent_of_graduate_enrollment_that_are_Black_or_African_American',
     'Percent_of_graduate_enrollment_that_are_Hispanic/Latino',
     'Percent_of_graduate_enrollment_that_are_Native_Hawaiian_or_Other_Pacific_Islander',
     'Percent_of_graduate_enrollment_that_are_White',
     'Percent_of_graduate_enrollment_that_are_two_or_more_races',
     'Percent_of_graduate_enrollment_that_are_Race/ethnicity_unknown',
     'Percent_of_graduate_enrollment_that_are_Nonresident_Alien',
     'Percent_of_graduate_enrollment_that_are_Asian/Native_Hawaiian/Pacific_Islander',
     'Percent_of_graduate_enrollment_that_are_women',
     'Graduation_rate_-_Bachelor_degree_within_4_years,_total',
     'Graduation_rate_-_Bachelor_degree_within_5_years,_total',
     'Graduation_rate_-_Bachelor_degree_within_6_years,_total',
     'Percent_of_freshmen_receiving_any_financial_aid',
     'Percent_of_freshmen_receiving_federal,_state,_local_or_institutional_grant_aid',
     'Percent_of_freshmen_receiving_federal_grant_aid',
     'Percent_of_freshmen_receiving_Pell_grants',
     'Percent_of_freshmen_receiving_other_federal_grant_aid',
     'Percent_of_freshmen_receiving_state/local_grant_aid',
     'Percent_of_freshmen_receiving_institutional_grant_aid',
     'Percent_of_freshmen_receiving_student_loan_aid',
     'Percent_of_freshmen_receiving_federal_student_loans',
     'Percent_of_freshmen_receiving_other_loan_aid']




```python
data.columns = new_title

data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID_number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP_code</th>
      <th>Highest_degree_offered</th>
      <th>County_name</th>
      <th>Longitude_location_of_institution</th>
      <th>Latitude_location_of_institution</th>
      <th>Religious_affiliation</th>
      <th>Offers_Less_than_one_year_certificate</th>
      <th>...</th>
      <th>Percent_of_freshmen_receiving_any_financial_aid</th>
      <th>Percent_of_freshmen_receiving_federal,_state,_local_or_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_Pell_grants</th>
      <th>Percent_of_freshmen_receiving_other_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_state/local_grant_aid</th>
      <th>Percent_of_freshmen_receiving_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_student_loan_aid</th>
      <th>Percent_of_freshmen_receiving_federal_student_loans</th>
      <th>Percent_of_freshmen_receiving_other_loan_aid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100654</td>
      <td>Alabama A &amp; M University</td>
      <td>2013</td>
      <td>35762</td>
      <td>Doctor's degree - research/scholarship</td>
      <td>Madison County</td>
      <td>-86.568502</td>
      <td>34.783368</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>97.0</td>
      <td>89.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>32.0</td>
      <td>89.0</td>
      <td>89.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100663</td>
      <td>University of Alabama at Birmingham</td>
      <td>2013</td>
      <td>35294-0110</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Jefferson County</td>
      <td>-86.809170</td>
      <td>33.502230</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>90.0</td>
      <td>79.0</td>
      <td>36.0</td>
      <td>36.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>56.0</td>
      <td>55.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100690</td>
      <td>Amridge University</td>
      <td>2013</td>
      <td>36117-3553</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.174010</td>
      <td>32.362609</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>0.0</td>
      <td>40.0</td>
      <td>90.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100706</td>
      <td>University of Alabama in Huntsville</td>
      <td>2013</td>
      <td>35899</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Madison County</td>
      <td>-86.638420</td>
      <td>34.722818</td>
      <td>Not applicable</td>
      <td>Yes</td>
      <td>...</td>
      <td>87.0</td>
      <td>77.0</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>63.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100724</td>
      <td>Alabama State University</td>
      <td>2013</td>
      <td>36104-0271</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.295677</td>
      <td>32.364317</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>93.0</td>
      <td>87.0</td>
      <td>76.0</td>
      <td>76.0</td>
      <td>13.0</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 127 columns</p>
</div>



Les 127 colonnes ont un intitulé uniforme.

## **Quelles sont les 20 universités ayant le plus grand nombre de candidatures**


```python
top20 = data[['Name', 'Applicants_total']].sort_values('Applicants_total', ascending=False).head(20)
top20
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Applicants_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>84</th>
      <td>University of California-Los Angeles</td>
      <td>72676.0</td>
    </tr>
    <tr>
      <th>81</th>
      <td>University of California-Berkeley</td>
      <td>61717.0</td>
    </tr>
    <tr>
      <th>86</th>
      <td>University of California-San Diego</td>
      <td>60832.0</td>
    </tr>
    <tr>
      <th>841</th>
      <td>New York University</td>
      <td>57845.0</td>
    </tr>
    <tr>
      <th>83</th>
      <td>University of California-Irvine</td>
      <td>56515.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>University of California-Santa Barbara</td>
      <td>55258.0</td>
    </tr>
    <tr>
      <th>77</th>
      <td>California State University-Long Beach</td>
      <td>55019.0</td>
    </tr>
    <tr>
      <th>863</th>
      <td>St John's University-New York</td>
      <td>51634.0</td>
    </tr>
    <tr>
      <th>126</th>
      <td>San Diego State University</td>
      <td>51163.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>University of California-Davis</td>
      <td>49820.0</td>
    </tr>
    <tr>
      <th>1371</th>
      <td>Liberty University</td>
      <td>48054.0</td>
    </tr>
    <tr>
      <th>1133</th>
      <td>Pennsylvania State University-Main Campus</td>
      <td>47552.0</td>
    </tr>
    <tr>
      <th>559</th>
      <td>Northeastern University</td>
      <td>47364.0</td>
    </tr>
    <tr>
      <th>137</th>
      <td>University of Southern California</td>
      <td>47358.0</td>
    </tr>
    <tr>
      <th>605</th>
      <td>University of Michigan-Ann Arbor</td>
      <td>46813.0</td>
    </tr>
    <tr>
      <th>529</th>
      <td>Boston University</td>
      <td>44006.0</td>
    </tr>
    <tr>
      <th>1080</th>
      <td>Drexel University</td>
      <td>43945.0</td>
    </tr>
    <tr>
      <th>634</th>
      <td>University of Minnesota-Twin Cities</td>
      <td>43048.0</td>
    </tr>
    <tr>
      <th>796</th>
      <td>Cornell University</td>
      <td>39999.0</td>
    </tr>
    <tr>
      <th>75</th>
      <td>California State University-Fullerton</td>
      <td>38909.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(16,10))
sns.barplot(x='Applicants_total', y='Name', data=top20, hue='Name', legend=False)
```




    <Axes: xlabel='Applicants_total', ylabel='Name'>




    
![png](output_38_1.png)
    



```python
plt.figure(figsize=(16,10))
sns.barplot(x='Applicants_total', y='Name', data=top20)
plt.title('Top 20', fontsize=16)
plt.xlabel('Candidatures')
plt.ylabel('Universités')
```




    Text(0, 0.5, 'Universités')




    
![png](output_39_1.png)
    


Les universités de 'Los Angeles', 'Berkeley' et 'San Diego' sont les 3 premières suivies de celle de 'New York'.

## **Y a-t-il une corélation en les candidature, les inscriptions & les admissions ?**


```python
df=data[['Applicants_total', 'Admissions_total', 'Enrolled_total']]
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Applicants_total</th>
      <th>Admissions_total</th>
      <th>Enrolled_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6142.0</td>
      <td>5521.0</td>
      <td>1104.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5689.0</td>
      <td>4934.0</td>
      <td>1773.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2054.0</td>
      <td>1656.0</td>
      <td>651.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10245.0</td>
      <td>5251.0</td>
      <td>1479.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
correlation=df.corr()
correlation
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Applicants_total</th>
      <th>Admissions_total</th>
      <th>Enrolled_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Applicants_total</th>
      <td>1.000000</td>
      <td>0.854956</td>
      <td>0.785045</td>
    </tr>
    <tr>
      <th>Admissions_total</th>
      <td>0.854956</td>
      <td>1.000000</td>
      <td>0.883965</td>
    </tr>
    <tr>
      <th>Enrolled_total</th>
      <td>0.785045</td>
      <td>0.883965</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



Il y a une forte corrélation entre les candidatures et les admissions.  
Idem pour les  admissions et les inscrits.  
Ainsi qu'entre les inscrits et les candidatures et les admissions.


```python
# graphique de corrélations
sns.heatmap(correlation, annot=True)
```




    <Axes: >




    
![png](output_45_1.png)
    


On voit la forte corrélation positive.

## **Classement**

### _Par candidatures_


```python
plt.figure(figsize = (14,8))

sns.histplot(data['Applicants_total'], bins = 40)                              # bins=interval
plt.title("Universités selon ls candidatures")
plt.xlabel("Candidatures")
plt.ylabel("Universités")
plt.axis([0,75000, 0,450])
```




    (np.float64(0.0), np.float64(75000.0), np.float64(0.0), np.float64(450.0))




    
![png](output_49_1.png)
    



```python
Moyenne = "La moyenne est {:.2f}".format(data['Applicants_total'].mean())
Mediane = "La mediane est {:.2f}".format(data['Applicants_total'].median())

print(Moyenne + "\n")
Mediane
```

    La moyenne est 6391.19
    





    'La mediane est 3350.00'



La majorité des universités ont moins de 5000 candidatures (3 premières barres).

### _Par admissions_


```python
plt.figure(figsize = (14,8))

sns.histplot(data['Admissions_total'], bins = 40)
plt.title("Universités selon les admissions")
plt.xlabel("Candidatures")
plt.ylabel("ºniversités")
plt.axis([0,75000, 0,450])

Moyenne = "La moyenne est {:.2f}".format(data['Admissions_total'].mean())
Mediane = "La mediane est {:.2f}".format(data['Admissions_total'].median())

print(Moyenne + "\n")
print(Mediane)
```

    La moyenne est 3554.88
    
    La mediane est 2056.00



    
![png](output_53_1.png)
    


Les 3 premières barres correspondent à environ 2500 ce qui est le nombre d'admissions de la majorité des universités.

### _Par inscription_


```python
plt.figure(figsize = (14,8))

sns.histplot(data['Enrolled_total'], bins = 30)
plt.title("ºniversités par inscriptions")
plt.xlabel("Candidatures")
plt.ylabel("Universités")
plt.axis([0,12000, 0,500])

Moyenne = "La moyenne est {:.2f}".format(data['Enrolled_total'].mean())
Mediane = "La mediane est {:.2f}".format(data['Enrolled_total'].median())

print(Moyenne + "\n")
print(Mediane)
```

    La moyenne est 1043.05
    
    La mediane est 538.00



    
![png](output_56_1.png)
    


Toules les moyennes et médianes corroborent.  
La majorité des universités ont environs moins de 1 000 inscrits.  
Peu en ont plus de 4 000.

## **Les universités au grand nombre d'admissions sont-elles préférées ?**


```python
plt.figure(figsize = (12,8))
sns.scatterplot(x = data.Applicants_total, y=data.Admissions_total, hue = data.Control_of_institution)
plt.xlabel("Candidatures")
plt.ylabel("Asmissions")
plt.title("Croisement des candidatures et admissions")
plt.grid()
```


    
![png](output_59_0.png)
    


Les universités avec le plus grand nombre de candidatures, n'ont pas le plus d'admissions.  
Celles qui sont privées ont beaucoup de candidatures et peu d'admissions (- 5 000).

## _Croisement des Admissions et inscriptions_


```python
plt.figure(figsize = (12,8))
sns.scatterplot(x = data.Admissions_total, y=data.Enrolled_total, hue = data.Control_of_institution)
plt.xlabel("Admissions")
plt.ylabel("Inscrits")
plt.title("Croisement des Admissions et inscriptions")
plt.grid()
```


    
![png](output_62_0.png)
    


Le résultat est analogue.  
Mais, ça peut prêter à confision.


```python
data['Enrollment_rate']=(data.Enrolled_total/data.Admissions_total*100).round(2)
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID_number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP_code</th>
      <th>Highest_degree_offered</th>
      <th>County_name</th>
      <th>Longitude_location_of_institution</th>
      <th>Latitude_location_of_institution</th>
      <th>Religious_affiliation</th>
      <th>Offers_Less_than_one_year_certificate</th>
      <th>...</th>
      <th>Percent_of_freshmen_receiving_federal,_state,_local_or_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_Pell_grants</th>
      <th>Percent_of_freshmen_receiving_other_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_state/local_grant_aid</th>
      <th>Percent_of_freshmen_receiving_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_student_loan_aid</th>
      <th>Percent_of_freshmen_receiving_federal_student_loans</th>
      <th>Percent_of_freshmen_receiving_other_loan_aid</th>
      <th>Enrollment_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100654</td>
      <td>Alabama A &amp; M University</td>
      <td>2013</td>
      <td>35762</td>
      <td>Doctor's degree - research/scholarship</td>
      <td>Madison County</td>
      <td>-86.568502</td>
      <td>34.783368</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>89.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>32.0</td>
      <td>89.0</td>
      <td>89.0</td>
      <td>1.0</td>
      <td>20.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100663</td>
      <td>University of Alabama at Birmingham</td>
      <td>2013</td>
      <td>35294-0110</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Jefferson County</td>
      <td>-86.809170</td>
      <td>33.502230</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>79.0</td>
      <td>36.0</td>
      <td>36.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>56.0</td>
      <td>55.0</td>
      <td>5.0</td>
      <td>35.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100690</td>
      <td>Amridge University</td>
      <td>2013</td>
      <td>36117-3553</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.174010</td>
      <td>32.362609</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>0.0</td>
      <td>40.0</td>
      <td>90.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100706</td>
      <td>University of Alabama in Huntsville</td>
      <td>2013</td>
      <td>35899</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Madison County</td>
      <td>-86.638420</td>
      <td>34.722818</td>
      <td>Not applicable</td>
      <td>Yes</td>
      <td>...</td>
      <td>77.0</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>63.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>3.0</td>
      <td>39.31</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100724</td>
      <td>Alabama State University</td>
      <td>2013</td>
      <td>36104-0271</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.295677</td>
      <td>32.364317</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>87.0</td>
      <td>76.0</td>
      <td>76.0</td>
      <td>13.0</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>28.17</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1529</th>
      <td>451671</td>
      <td>University of South Florida-Sarasota-Manatee</td>
      <td>2013</td>
      <td>34243-2049</td>
      <td>Master's degree</td>
      <td>Manatee County</td>
      <td>-82.562951</td>
      <td>27.391766</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>63.24</td>
    </tr>
    <tr>
      <th>1530</th>
      <td>454184</td>
      <td>The Kingâ€™s College</td>
      <td>2013</td>
      <td>10004</td>
      <td>Bachelor's degree</td>
      <td>New York County</td>
      <td>-74.012348</td>
      <td>40.706861</td>
      <td>Interdenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>34.0</td>
      <td>34.0</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>100.0</td>
      <td>57.0</td>
      <td>56.0</td>
      <td>12.0</td>
      <td>5.89</td>
    </tr>
    <tr>
      <th>1531</th>
      <td>454582</td>
      <td>Ottawa University-Online</td>
      <td>2013</td>
      <td>66067</td>
      <td>Master's degree</td>
      <td>Franklin County</td>
      <td>-95.263775</td>
      <td>38.602692</td>
      <td>American Baptist</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1532</th>
      <td>455770</td>
      <td>Providence Christian College</td>
      <td>2013</td>
      <td>91104</td>
      <td>Bachelor's degree</td>
      <td>Los Angeles County</td>
      <td>-118.118491</td>
      <td>34.172750</td>
      <td>Undenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>14.0</td>
      <td>0.0</td>
      <td>100.0</td>
      <td>64.0</td>
      <td>64.0</td>
      <td>14.0</td>
      <td>30.77</td>
    </tr>
    <tr>
      <th>1533</th>
      <td>456490</td>
      <td>Polytechnic University of Puerto Rico-Orlando</td>
      <td>2013</td>
      <td>32825</td>
      <td>Master's degree</td>
      <td>Orange County</td>
      <td>-81.254951</td>
      <td>28.551470</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1534 rows × 128 columns</p>
</div>




```python
plt.figure(figsize = (12,8))
sns.scatterplot(x = data.Admissions_total, y = data.Enrollment_rate)
plt.xlabel("Admissioins")
plt.ylabel("Taux d'inscription")
plt.title("Coroiseemnt des admissions et du taux inscriptions")
```




    Text(0.5, 1.0, 'Coroiseemnt des admissions et du taux inscriptions')




    
![png](output_65_1.png)
    


S'il y a un grand nombre d'inscriptions, les admissions sont faibles.  
Et vice versa.  
Un étudiant peut être admis à une université sans s'y être inscrit.  
Un grand nombre de candidatures, n'est pas dû à une préférence des étudiants.

## **Les étudient préfèrent-ils les universités publiques ou privées ?**


```python
plt.figure(figsize = (12,6))
sns.barplot(x = data.Control_of_institution, y=data.Applicants_total)
plt.title("Moyenne de candidatures selon le type les unversités publiques ou privées")
plt.xlabel("Type d'unversité")
plt.ylabel("Candidatures")
```




    Text(0, 0.5, 'Candidatures')




    
![png](output_68_1.png)
    


Les universités publiques ont nettement plus de candidatures (environ le double).  
Cela pourrait être dû au coût, aux conditions, les études proposées, ...  
L'analyse doit aller plus loins.

## **Croisement des candidatures et des universités publiques & privées**

###  _Couper le dataframe en 2_


```python
private = data[data.Control_of_institution =="Private not-for-profit" ]
public  = data[data.Control_of_institution =="Public" ]
public
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID_number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP_code</th>
      <th>Highest_degree_offered</th>
      <th>County_name</th>
      <th>Longitude_location_of_institution</th>
      <th>Latitude_location_of_institution</th>
      <th>Religious_affiliation</th>
      <th>Offers_Less_than_one_year_certificate</th>
      <th>...</th>
      <th>Percent_of_freshmen_receiving_federal,_state,_local_or_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_Pell_grants</th>
      <th>Percent_of_freshmen_receiving_other_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_state/local_grant_aid</th>
      <th>Percent_of_freshmen_receiving_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_student_loan_aid</th>
      <th>Percent_of_freshmen_receiving_federal_student_loans</th>
      <th>Percent_of_freshmen_receiving_other_loan_aid</th>
      <th>Enrollment_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100654</td>
      <td>Alabama A &amp; M University</td>
      <td>2013</td>
      <td>35762</td>
      <td>Doctor's degree - research/scholarship</td>
      <td>Madison County</td>
      <td>-86.568502</td>
      <td>34.783368</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>89.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>7.0</td>
      <td>1.0</td>
      <td>32.0</td>
      <td>89.0</td>
      <td>89.0</td>
      <td>1.0</td>
      <td>20.00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100663</td>
      <td>University of Alabama at Birmingham</td>
      <td>2013</td>
      <td>35294-0110</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Jefferson County</td>
      <td>-86.809170</td>
      <td>33.502230</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>79.0</td>
      <td>36.0</td>
      <td>36.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>60.0</td>
      <td>56.0</td>
      <td>55.0</td>
      <td>5.0</td>
      <td>35.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100706</td>
      <td>University of Alabama in Huntsville</td>
      <td>2013</td>
      <td>35899</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Madison County</td>
      <td>-86.638420</td>
      <td>34.722818</td>
      <td>Not applicable</td>
      <td>Yes</td>
      <td>...</td>
      <td>77.0</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>63.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>3.0</td>
      <td>39.31</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100724</td>
      <td>Alabama State University</td>
      <td>2013</td>
      <td>36104-0271</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.295677</td>
      <td>32.364317</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>87.0</td>
      <td>76.0</td>
      <td>76.0</td>
      <td>13.0</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>81.0</td>
      <td>81.0</td>
      <td>0.0</td>
      <td>28.17</td>
    </tr>
    <tr>
      <th>5</th>
      <td>100751</td>
      <td>The University of Alabama</td>
      <td>2013</td>
      <td>35487-0166</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Tuscaloosa County</td>
      <td>-87.545766</td>
      <td>33.214400</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>60.0</td>
      <td>20.0</td>
      <td>18.0</td>
      <td>4.0</td>
      <td>3.0</td>
      <td>50.0</td>
      <td>42.0</td>
      <td>41.0</td>
      <td>8.0</td>
      <td>36.85</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1510</th>
      <td>441900</td>
      <td>Nevada State College</td>
      <td>2013</td>
      <td>89002</td>
      <td>Bachelor's degree</td>
      <td>Clark County</td>
      <td>-114.938929</td>
      <td>35.987249</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>82.0</td>
      <td>52.0</td>
      <td>52.0</td>
      <td>3.0</td>
      <td>59.0</td>
      <td>24.0</td>
      <td>36.0</td>
      <td>35.0</td>
      <td>1.0</td>
      <td>47.56</td>
    </tr>
    <tr>
      <th>1511</th>
      <td>441937</td>
      <td>California State University-Channel Islands</td>
      <td>2013</td>
      <td>93012</td>
      <td>Master's degree</td>
      <td>Ventura County</td>
      <td>-119.043560</td>
      <td>34.162949</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>54.0</td>
      <td>45.0</td>
      <td>45.0</td>
      <td>2.0</td>
      <td>38.0</td>
      <td>41.0</td>
      <td>49.0</td>
      <td>48.0</td>
      <td>2.0</td>
      <td>16.86</td>
    </tr>
    <tr>
      <th>1520</th>
      <td>447689</td>
      <td>Georgia Gwinnett College</td>
      <td>2013</td>
      <td>30043</td>
      <td>Bachelor's degree</td>
      <td>Gwinnett County</td>
      <td>-84.001135</td>
      <td>33.979915</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>72.0</td>
      <td>59.0</td>
      <td>59.0</td>
      <td>1.0</td>
      <td>26.0</td>
      <td>2.0</td>
      <td>46.0</td>
      <td>46.0</td>
      <td>1.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1525</th>
      <td>448840</td>
      <td>University of South Florida-St Petersburg</td>
      <td>2013</td>
      <td>33701-9807</td>
      <td>Master's degree</td>
      <td>Pinellas County</td>
      <td>-82.635657</td>
      <td>27.762618</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>91.0</td>
      <td>45.0</td>
      <td>44.0</td>
      <td>5.0</td>
      <td>80.0</td>
      <td>43.0</td>
      <td>51.0</td>
      <td>51.0</td>
      <td>1.0</td>
      <td>39.97</td>
    </tr>
    <tr>
      <th>1529</th>
      <td>451671</td>
      <td>University of South Florida-Sarasota-Manatee</td>
      <td>2013</td>
      <td>34243-2049</td>
      <td>Master's degree</td>
      <td>Manatee County</td>
      <td>-82.562951</td>
      <td>27.391766</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>63.24</td>
    </tr>
  </tbody>
</table>
<p>563 rows × 128 columns</p>
</div>




```python
private
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID_number</th>
      <th>Name</th>
      <th>year</th>
      <th>ZIP_code</th>
      <th>Highest_degree_offered</th>
      <th>County_name</th>
      <th>Longitude_location_of_institution</th>
      <th>Latitude_location_of_institution</th>
      <th>Religious_affiliation</th>
      <th>Offers_Less_than_one_year_certificate</th>
      <th>...</th>
      <th>Percent_of_freshmen_receiving_federal,_state,_local_or_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_Pell_grants</th>
      <th>Percent_of_freshmen_receiving_other_federal_grant_aid</th>
      <th>Percent_of_freshmen_receiving_state/local_grant_aid</th>
      <th>Percent_of_freshmen_receiving_institutional_grant_aid</th>
      <th>Percent_of_freshmen_receiving_student_loan_aid</th>
      <th>Percent_of_freshmen_receiving_federal_student_loans</th>
      <th>Percent_of_freshmen_receiving_other_loan_aid</th>
      <th>Enrollment_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>100690</td>
      <td>Amridge University</td>
      <td>2013</td>
      <td>36117-3553</td>
      <td>Doctor's degree - research/scholarship and pro...</td>
      <td>Montgomery County</td>
      <td>-86.174010</td>
      <td>32.362609</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>90.0</td>
      <td>0.0</td>
      <td>40.0</td>
      <td>90.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>100937</td>
      <td>Birmingham Southern College</td>
      <td>2013</td>
      <td>35254</td>
      <td>Bachelor's degree</td>
      <td>Jefferson County</td>
      <td>-86.853636</td>
      <td>33.515453</td>
      <td>United Methodist</td>
      <td>Implied no</td>
      <td>...</td>
      <td>97.0</td>
      <td>21.0</td>
      <td>21.0</td>
      <td>9.0</td>
      <td>26.0</td>
      <td>96.0</td>
      <td>80.0</td>
      <td>80.0</td>
      <td>7.0</td>
      <td>28.71</td>
    </tr>
    <tr>
      <th>10</th>
      <td>101073</td>
      <td>Concordia College Alabama</td>
      <td>2013</td>
      <td>36701</td>
      <td>Bachelor's degree</td>
      <td>Dallas County</td>
      <td>-87.023531</td>
      <td>32.424430</td>
      <td>Lutheran Church - Missouri Synod</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>84.0</td>
      <td>16.0</td>
      <td>83.0</td>
      <td>67.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>101189</td>
      <td>Faulkner University</td>
      <td>2013</td>
      <td>36109-3378</td>
      <td>Doctor's degree -  professional practice</td>
      <td>Montgomery County</td>
      <td>-86.216410</td>
      <td>32.384181</td>
      <td>Churches of Christ</td>
      <td>Implied no</td>
      <td>...</td>
      <td>99.0</td>
      <td>57.0</td>
      <td>57.0</td>
      <td>34.0</td>
      <td>64.0</td>
      <td>91.0</td>
      <td>79.0</td>
      <td>79.0</td>
      <td>3.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>12</th>
      <td>101435</td>
      <td>Huntingdon College</td>
      <td>2013</td>
      <td>36106-2148</td>
      <td>Bachelor's degree</td>
      <td>Montgomery County</td>
      <td>-86.285313</td>
      <td>32.350939</td>
      <td>United Methodist</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>48.0</td>
      <td>48.0</td>
      <td>16.0</td>
      <td>53.0</td>
      <td>99.0</td>
      <td>78.0</td>
      <td>77.0</td>
      <td>10.0</td>
      <td>28.28</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1528</th>
      <td>450766</td>
      <td>LIU Riverhead</td>
      <td>2013</td>
      <td>11901-3499</td>
      <td>Master's degree</td>
      <td>Suffolk County</td>
      <td>-72.699100</td>
      <td>40.876143</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1530</th>
      <td>454184</td>
      <td>The Kingâ€™s College</td>
      <td>2013</td>
      <td>10004</td>
      <td>Bachelor's degree</td>
      <td>New York County</td>
      <td>-74.012348</td>
      <td>40.706861</td>
      <td>Interdenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>34.0</td>
      <td>34.0</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>100.0</td>
      <td>57.0</td>
      <td>56.0</td>
      <td>12.0</td>
      <td>5.89</td>
    </tr>
    <tr>
      <th>1531</th>
      <td>454582</td>
      <td>Ottawa University-Online</td>
      <td>2013</td>
      <td>66067</td>
      <td>Master's degree</td>
      <td>Franklin County</td>
      <td>-95.263775</td>
      <td>38.602692</td>
      <td>American Baptist</td>
      <td>Implied no</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1532</th>
      <td>455770</td>
      <td>Providence Christian College</td>
      <td>2013</td>
      <td>91104</td>
      <td>Bachelor's degree</td>
      <td>Los Angeles County</td>
      <td>-118.118491</td>
      <td>34.172750</td>
      <td>Undenominational</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>14.0</td>
      <td>0.0</td>
      <td>100.0</td>
      <td>64.0</td>
      <td>64.0</td>
      <td>14.0</td>
      <td>30.77</td>
    </tr>
    <tr>
      <th>1533</th>
      <td>456490</td>
      <td>Polytechnic University of Puerto Rico-Orlando</td>
      <td>2013</td>
      <td>32825</td>
      <td>Master's degree</td>
      <td>Orange County</td>
      <td>-81.254951</td>
      <td>28.551470</td>
      <td>Not applicable</td>
      <td>Implied no</td>
      <td>...</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>100.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>0.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>971 rows × 128 columns</p>
</div>




```python
# que la colonne concernée
public['Control_of_institution'].head(50)
```




    0     Public
    1     Public
    3     Public
    4     Public
    5     Public
    6     Public
    7     Public
    8     Public
    13    Public
    15    Public
    18    Public
    19    Public
    22    Public
    26    Public
    28    Public
    29    Public
    30    Public
    33    Public
    34    Public
    36    Public
    40    Public
    43    Public
    44    Public
    45    Public
    46    Public
    47    Public
    48    Public
    51    Public
    58    Public
    59    Public
    66    Public
    68    Public
    69    Public
    70    Public
    71    Public
    72    Public
    73    Public
    74    Public
    75    Public
    76    Public
    77    Public
    78    Public
    79    Public
    80    Public
    81    Public
    82    Public
    83    Public
    84    Public
    85    Public
    86    Public
    Name: Control_of_institution, dtype: object




```python
# que la colonne concernée
private['Control_of_institution'].head(50)
```




    2      Private not-for-profit
    9      Private not-for-profit
    10     Private not-for-profit
    11     Private not-for-profit
    12     Private not-for-profit
    14     Private not-for-profit
    16     Private not-for-profit
    17     Private not-for-profit
    20     Private not-for-profit
    21     Private not-for-profit
    23     Private not-for-profit
    24     Private not-for-profit
    25     Private not-for-profit
    27     Private not-for-profit
    31     Private not-for-profit
    32     Private not-for-profit
    35     Private not-for-profit
    37     Private not-for-profit
    38     Private not-for-profit
    39     Private not-for-profit
    41     Private not-for-profit
    42     Private not-for-profit
    49     Private not-for-profit
    50     Private not-for-profit
    52     Private not-for-profit
    53     Private not-for-profit
    54     Private not-for-profit
    55     Private not-for-profit
    56     Private not-for-profit
    57     Private not-for-profit
    60     Private not-for-profit
    61     Private not-for-profit
    62     Private not-for-profit
    63     Private not-for-profit
    64     Private not-for-profit
    65     Private not-for-profit
    67     Private not-for-profit
    90     Private not-for-profit
    91     Private not-for-profit
    92     Private not-for-profit
    93     Private not-for-profit
    94     Private not-for-profit
    95     Private not-for-profit
    96     Private not-for-profit
    97     Private not-for-profit
    98     Private not-for-profit
    99     Private not-for-profit
    100    Private not-for-profit
    101    Private not-for-profit
    103    Private not-for-profit
    Name: Control_of_institution, dtype: object




```python
plt.figure(figsize = (16,7))
plt.hist([public.Applicants_total, private.Applicants_total], bins = 25, stacked = True)
plt.axis([0,50000,0,700])
plt.title("Candidatures par université publique ou privé")
plt.xlabel("Candidatues")
plt.ylabel("Universités")
plt.legend(['Universités publiques. ({})'.format(len(public)),
            'Universités privées. ({})'.format(len(private))])
```




    <matplotlib.legend.Legend at 0x17b680b90>




    
![png](output_76_1.png)
    


Il y a plus d'universités privées.  
Les universités privées reçoivent généralement moins de 5 000 candidatures.  

## **Y a-t-il une relation entre le taux d'inscription et le type d'université ?**


```python
plt.figure(figsize = (12,6))
sns.barplot(x = data.Control_of_institution, y = data.Enrollment_rate)
plt.title("Le taux d'inscription selon le type d'universités")
plt.xlabel("Universités")
plt.ylabel("Taux d'inscription")
```




    Text(0, 0.5, "Taux d'inscription")




    
![png](output_79_1.png)
    


Les universités publiques reçoivent plus de candidatures.


```python
total = data['Enrollment_rate'].sum()
data['Enrollment_pct'] = (data['Enrollment_rate'] / total) * 100

plt.figure(figsize=(12,6))
sns.barplot(x=data['Control_of_institution'], y=data['Enrollment_pct'])
plt.title("Le taux d'inscription selon le type d'universités (%)")
plt.xlabel("Universités")
plt.ylabel("Taux d'inscription (%)")
plt.show()
```


    
![png](output_81_0.png)
    


Le nombre de candidatures n'est pas un gage de préférence.  
Sauf exception, les universités ayant moins de candidatures ont plus d'admissions.  
Le taux d'admissions n'est pas un signe d'influence.  
Les universités publiques ont plus d'admissions.
